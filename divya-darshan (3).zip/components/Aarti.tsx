import React from 'react';

// This component is no longer used and has been gutted to remove the feature.
export const Aarti = () => {
    return null;
};
